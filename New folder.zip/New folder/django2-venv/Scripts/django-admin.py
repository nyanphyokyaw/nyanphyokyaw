#!F:\Npk Pagemyanmr Module-2\Python\15_django\1_example\1_create_project\django2-venv\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
