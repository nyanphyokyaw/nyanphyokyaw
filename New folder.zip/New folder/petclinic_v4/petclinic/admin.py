from django.contrib import admin

# Register your models here.
from .models import *

class PetTypeAdmin(admin.ModelAdmin):
	list_display = ['name']
admin.site.register(PetType,PetTypeAdmin)

class PetAdmin(admin.ModelAdmin):
	list_display = ['owner_id','name','pettype','birthday']
admin.site.register(Pet,PetAdmin)

class OwnerAdmin(admin.ModelAdmin):
	list_display = ['first_name','last_name','address','city','telephone']
admin.site.register(Owner,OwnerAdmin)

class SpecialtyAdmin(admin.ModelAdmin):
	list_display = ['name']
admin.site.register(Specialty,SpecialtyAdmin)

class VetAdmin(admin.ModelAdmin):
	list_display = ['first_name','last_name']
admin.site.register(Vet,VetAdmin)

class VisitAdmin(admin.ModelAdmin):
	list_display = ['visit_date','description','pet']
admin.site.register(Visit,VisitAdmin)