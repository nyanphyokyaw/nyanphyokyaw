from django.shortcuts import render, redirect

from ..models import Pet
from ..form import PetForm

def add_pet(request, owner_id):
	if request.method == "POST":
		form = PetForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect("/petclinic/owners/" + str(owner_id) + '/')
	else:
		form= PetForm(initial={'owner_id': owner_id})
	return render(request,'pets/add.html', {'form': form})